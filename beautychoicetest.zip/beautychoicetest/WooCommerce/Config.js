'use strict';

const Constants = {
    URL: {
        root: 'https://beautychoice.in'
    },
    Keys: {
        ConsumerKey: 'ck_3cd7708189f48bfef106281a30282fe8b62799f4',
	    ConsumerSecret: 'cs_cf97f534be8b3230ccc5d96d39dd9699e5e310c8'
    }
}

module.exports = Constants;
